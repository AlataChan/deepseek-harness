/**
 * TUI bundle entry point.
 * @module @deepseek-ai/dsh-tui-bundle
 */
import type { Context } from '@deepseek-ai/cordis';
export declare const name = "tui-bundle";
/**
 * Apply the TUI bundle plugin.
 * @param _ctx - Cordis context.
 */
export declare function apply(_ctx: Context): void;
//# sourceMappingURL=index.d.ts.map