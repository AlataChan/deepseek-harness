/**
 * Interactive Terminal User Interface (TUI) Cordis plugin entry.
 * Function plugin with no default export, adhering to harness plugin conventions.
 *
 * @module @deepseek-ai/dsh-tui
 */
import { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import type { TuiConfig } from './types.ts';
export * from './types.ts';
export * from './locales.ts';
export * from './render.ts';
export * from './input.ts';
export * from './session.ts';
export * from './interaction.ts';
export declare const name = "tui";
export declare const inject: string[];
export declare const Config: z<TuiConfig>;
/**
 * Apply the interactive TUI plugin to the Cordis context.
 * @param ctx - Cordis Context.
 * @param config - Plugin configuration options.
 */
export declare function apply(ctx: Context, config?: TuiConfig): void;
//# sourceMappingURL=index.d.ts.map