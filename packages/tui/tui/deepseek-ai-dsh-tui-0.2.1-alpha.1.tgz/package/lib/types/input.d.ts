/**
 * TTY raw mode, bounded bracketed paste, multiline buffer, and key routing.
 * Uses an incremental state-machine parser to handle escape sequences and
 * bracketed paste markers split across arbitrary chunk boundaries.
 *
 * @module @deepseek-ai/dsh-tui/input
 */
export interface InputHandlers {
    /** Called when the user presses Enter to submit a command or prompt. */
    onSubmit: (text: string) => void;
    /** Called when the user presses Ctrl+C. */
    onCancel: () => void;
    /** Called on normal exit (Ctrl+D on empty line, or double Ctrl+C). */
    onExit: () => void;
    /** Called whenever draft text or cursor changes to request a re-render. */
    onRender: () => void;
}
/** Maximum bytes permitted in a single bracketed paste payload. */
export declare const MAX_PASTE_BYTES = 65536;
/** Maximum entries retained in input command history. */
export declare const MAX_HISTORY_ENTRIES = 500;
/**
 * Sanitize text destined for the input draft buffer.
 * Strips all C0 controls (except newline and tab), C1 controls (including 8-bit CSI),
 * and ANSI/OSC escape sequences. Converts carriage returns and tabs cleanly.
 *
 * @param text - Raw untrusted or pasted text.
 * @returns Safe printable text string.
 */
export declare function sanitizeDraftText(text: string): string;
/** Input controller managing raw terminal keystrokes, incremental parsing, and line editing. */
export declare class InputController {
    private readonly stdin;
    private readonly handlers;
    private readonly maxInputBytes;
    private draft;
    private cursorGraphemeIndex;
    private parserState;
    private escapeBuffer;
    private pasteBuffer;
    private ctrlCPressCount;
    private multilineMode;
    private readonly history;
    private historyIndex;
    private uninstalled;
    constructor(stdin: NodeJS.ReadStream | undefined, handlers: InputHandlers, maxInputBytes?: number);
    /**
     * Start listening for raw input on stdin.
     * Enables raw mode on TTY streams.
     */
    start(): void;
    /** Stop listening and restore stdin mode. */
    stop(): void;
    /**
     * Get the current input draft string.
     * @returns Current draft text.
     */
    getDraft(): string;
    /**
     * Set the draft text programmatically.
     * @param text - New draft content.
     */
    setDraft(text: string): void;
    /**
     * Get the cursor position in grapheme cluster units.
     * @returns Current 0-based grapheme index.
     */
    getCursorIndex(): number;
    /** Clear the current draft buffer. */
    clearDraft(): void;
    /**
     * Process an incoming text or escape sequence chunk incrementally.
     * Safe against arbitrary splitting across byte or chunk boundaries.
     * @param chunk - Raw input bytes or characters.
     */
    handleChunk(chunk: string): void;
    /** Toggle multiline edit mode. */
    toggleMultiline(): boolean;
    private handleData;
    private consumeChar;
    private consumeGround;
    private consumeEscape;
    private consumeCsi;
    private dispatchCsi;
    private consumeSs3;
    private consumePaste;
    private consumePasteEsc;
    private consumePasteCsi;
    private insertText;
    private handleBackspace;
    private handleDelete;
    private recordHistory;
    private navigateHistoryPrevious;
    private navigateHistoryNext;
}
//# sourceMappingURL=input.d.ts.map