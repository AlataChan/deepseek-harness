/**
 * Session adapter and command routing for the interactive terminal user interface.
 * Owns a single active AgentHandle, connects model streaming, session switching,
 * replay reconstruction, draft-until-idle queueing, and presenter metadata rendering.
 *
 * @module @deepseek-ai/dsh-tui/session
 */
import type { Context } from '@deepseek-ai/cordis';
import { type Agent, type ModelSelection } from '@deepseek-ai/dsh-agent';
import { SessionId } from '@deepseek-ai/dsh-session';
import type { TerminalRenderer } from './render.ts';
import type { LocaleDictionary } from './locales.ts';
import type { TuiStatus } from './types.ts';
export interface SessionAdapterHandlers {
    onStatusChange: (status: TuiStatus) => void;
    onModelChange: (model: string) => void;
    onSessionChange: (sessionId: string) => void;
    onRenderRequest: (streamingText?: string) => void;
}
/** Manages the active agent handle, prompt submissions, commands, and stream notifications. */
export declare class SessionAdapter {
    private readonly ctx;
    private readonly renderer;
    private readonly handlers;
    private readonly dict;
    private activeHandle;
    private activeModelSelection;
    private currentStatus;
    private streamAttemptId;
    private streamAccumulator;
    private lastRenderedSeq;
    private pendingPrompt;
    private isTransitioning;
    private disposed;
    constructor(ctx: Context, renderer: TerminalRenderer, handlers: SessionAdapterHandlers, dict: LocaleDictionary);
    /** Current active Agent instance, if any. */
    get agent(): Agent | undefined;
    /** Current active Session ID string. */
    get sessionId(): string;
    /** Current active Model label string. */
    get modelLabel(): string;
    /**
     * Initialize a fresh default session on startup.
     */
    initDefaultSession(): Promise<void>;
    /**
     * Create a new agent session.
     * @param id - Unique SessionId.
     */
    createSession(id: SessionId): Promise<void>;
    /**
     * Resume an existing persisted session.
     * @param id - SessionId to load and resume.
     */
    resumeSession(id: SessionId): Promise<void>;
    /**
     * Submit a user message prompt to the active session.
     * Queues input as draft-until-idle if a turn is already executing.
     * @param text - Prompt content string.
     */
    submitPrompt(text: string): Promise<void>;
    /**
     * Cancel the currently running agent turn.
     */
    cancelActiveTurn(): void;
    /**
     * Set the model selection for subsequent requests.
     * @param selection - Provider, model, and optional reasoning effort.
     */
    setModel(selection: ModelSelection): void;
    /**
     * Dispose and teardown active agent handle cleanly.
     */
    dispose(): Promise<void>;
    private resetSessionState;
    private setStatus;
    private quiesceAndRelease;
    private setupListeners;
    private handleStreamFrame;
    private handleSessionEvent;
    private replayHistory;
    private handleCommand;
}
//# sourceMappingURL=session.d.ts.map