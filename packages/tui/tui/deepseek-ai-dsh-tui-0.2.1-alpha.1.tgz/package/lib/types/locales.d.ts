/**
 * Typed locale dictionary for the interactive terminal user interface.
 * Supports Chinese (default) and English.
 *
 * @module @deepseek-ai/dsh-tui/locales
 */
export interface LocaleDictionary {
    readonly appTitle: string;
    readonly statusIdle: string;
    readonly statusRunning: string;
    readonly statusCancelling: string;
    readonly statusWaitingApproval: string;
    readonly statusWaitingQuestion: string;
    readonly statusExiting: string;
    readonly inputPlaceholder: string;
    readonly inputHint: string;
    readonly multilineHint: string;
    readonly bracketedPasteNotice: string;
    readonly approvalTitle: string;
    readonly approvalTool: string;
    readonly approvalReason: string;
    readonly approvalArgs: string;
    readonly approvalArgsUnavailable: string;
    readonly approvalOptionAllow: string;
    readonly approvalOptionReject: string;
    readonly approvalOptionCancel: string;
    readonly approvalEnterWarning: string;
    readonly questionTitle: string;
    readonly questionSingleChoiceHint: string;
    readonly questionMultiChoiceHint: string;
    readonly questionSubmitHint: string;
    readonly questionCustomPrompt: string;
    readonly approvalOutcomeAllowed: string;
    readonly approvalOutcomeRejected: string;
    readonly approvalOutcomeCancelled: string;
    readonly questionAnswerSelected: string;
    readonly questionAnswerCustom: string;
    readonly questionProgress: string;
    readonly questionInvalidChoice: string;
    readonly modelCurrent: string;
    readonly modelSelectPrompt: string;
    readonly modelSwitchNotice: string;
    readonly sessionCurrent: string;
    readonly sessionWorkspace: string;
    readonly sessionListHeader: string;
    readonly sessionNoHistory: string;
    readonly sessionCreated: string;
    readonly sessionResumed: string;
    readonly sessionConflictError: string;
    readonly commandHelpTitle: string;
    readonly commandHelpText: string;
    readonly errorTtyRequired: string;
    readonly errorOperationFailed: string;
    readonly exitGoodbye: string;
}
/**
 * Get the locale dictionary for the requested language code.
 * @param locale - 'zh' or 'en'.
 * @returns The matching LocaleDictionary.
 */
export declare function getLocale(locale?: 'zh' | 'en'): LocaleDictionary;
//# sourceMappingURL=locales.d.ts.map