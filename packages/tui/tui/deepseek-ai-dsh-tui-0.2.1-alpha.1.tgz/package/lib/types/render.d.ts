/**
 * Bounded, sanitized terminal rendering, streaming presentation, and escape sequence management.
 * Provides grapheme-aware width measurement, complete C0/C1 and ANSI filtering,
 * shared tool card rendering, multiline cursor placement, and safe terminal state restoration.
 *
 * @module @deepseek-ai/dsh-tui/render
 */
import type { ToolCallView, ToolResultView } from '@deepseek-ai/dsh-tools';
import type { ScrollbackLine, TuiStatus } from './types.ts';
import type { LocaleDictionary } from './locales.ts';
/**
 * Split text into grapheme clusters using Intl.Segmenter.
 * @param text - Input string to segment.
 * @returns Array of grapheme cluster strings.
 */
export declare function splitGraphemes(text: string): string[];
/**
 * Measure display column width of a string or grapheme cluster.
 * @param text - Text to measure.
 * @returns Column count on standard terminal.
 */
export declare function measureWidth(text: string): number;
/**
 * Strip all ANSI, CSI, OSC (e.g. OSC 52), C0 (except newline/tab), and C1 controls from untrusted output.
 * @param text - Untrusted model, tool, or pasted output.
 * @returns Sanitized plain text safe for terminal rendering.
 */
export declare function sanitizeUntrustedOutput(text: string): string;
/**
 * Wrap a single line of text into multiple lines fitting within maxWidth columns.
 * Word/grapheme boundary aware.
 * @param text - Line text to wrap.
 * @param maxWidth - Column width limit.
 * @returns Array of wrapped line strings.
 */
export declare function wrapTextToWidth(text: string, maxWidth: number): string[];
/** Global restoration state tracking modes entered by the TUI. */
export interface TerminalModeState {
    enteredAlternateScreen: boolean;
    bracketedPasteEnabled: boolean;
    cursorHidden: boolean;
    originalIsRaw?: boolean | undefined;
    admissionStopped: boolean;
}
/**
 * Get active terminal mode state tracking for auditing or diagnostics.
 * @returns Clone of active terminal mode flags.
 */
export declare function getTerminalModeState(): Readonly<TerminalModeState>;
/**
 * Enter the terminal's alternate screen buffer and enable bracketed paste.
 * @param stdout - Process stdout stream.
 * @param stdin - Process stdin stream to record original raw state.
 */
export declare function enterAlternateScreen(stdout?: NodeJS.WriteStream, stdin?: NodeJS.ReadStream): void;
/**
 * Check whether the alternate screen is currently active.
 * @returns true if entered and not yet restored.
 */
export declare function isAlternateScreenActive(): boolean;
/**
 * Synchronously restore terminal state. Idempotent and exception-contained.
 * Restores only the terminal modes that were actually entered, restores original raw mode,
 * and marks admission as stopped.
 *
 * @param stdout - Process stdout stream.
 * @param stdin - Process stdin stream.
 */
export declare function restoreTerminalNow(stdout?: NodeJS.WriteStream, stdin?: NodeJS.ReadStream): void;
/**
 * Render a tool call view into a human-readable formatted terminal card.
 * @param view - Provider-neutral ToolCallView.
 * @returns Formatted lines describing the call.
 */
export declare function renderToolCallView(view: ToolCallView): string;
/**
 * Render a tool result view into a human-readable formatted terminal card.
 * @param view - Provider-neutral ToolResultView.
 * @returns Formatted lines describing the result.
 */
export declare function renderToolResultView(view: ToolResultView): string;
/** State passed to {@link TerminalRenderer.render}. */
export interface RenderState {
    sessionId: string;
    workspace: string;
    model: string;
    status: TuiStatus;
    draft: string;
    cursorGraphemeIndex: number;
    interactionPrompt?: string | undefined;
    streamingText?: string | undefined;
}
/** Terminal renderer managing output lines, streaming, multiline draft, and view composing. */
export declare class TerminalRenderer {
    private readonly maxScrollback;
    private readonly stdout;
    private readonly scrollback;
    constructor(maxScrollback?: number, stdout?: NodeJS.WriteStream);
    /**
     * Append one line to the scrollback buffer, enforcing memory bounds.
     * @param text - Line content.
     * @param kind - Semantic category of line.
     */
    appendLine(text: string, kind?: ScrollbackLine['kind']): void;
    /** Clear all scrollback lines. */
    clear(): void;
    /**
     * Get all active scrollback lines.
     * @returns Readonly array of scrollback lines.
     */
    getLines(): readonly ScrollbackLine[];
    /**
     * Render the complete terminal view.
     * Uses explicit line addressing (\x1b[row;1H) to avoid trailing newline scrolling.
     * Calculates cursor position accurately for multiline, column-wrapped drafts.
     *
     * @param state - Current UI header state, input buffer, streaming deltas, and prompt info.
     * @param dict - Locale dictionary.
     */
    render(state: RenderState, dict: LocaleDictionary): void;
}
//# sourceMappingURL=render.d.ts.map