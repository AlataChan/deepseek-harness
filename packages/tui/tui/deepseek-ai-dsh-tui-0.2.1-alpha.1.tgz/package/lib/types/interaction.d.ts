/**
 * Approval and user-questions terminal interaction provider.
 * Manages human confirmation prompts, PTC dispatch-start subCallId argument lookup,
 * serialized FIFO interaction queue, recursive secret redaction, and fail-closed security invariants.
 *
 * @module @deepseek-ai/dsh-tui/interaction
 */
import type { Context } from '@deepseek-ai/cordis';
import type { Agent } from '@deepseek-ai/dsh-agent';
import { type Session } from '@deepseek-ai/dsh-session';
import type { TerminalRenderer } from './render.ts';
import type { LocaleDictionary } from './locales.ts';
/** Summary and status of arguments discovered for a tool call. */
export interface ApprovalArgumentsInfo {
    readonly found: boolean;
    readonly argumentsSummary: string;
    readonly kind?: 'native' | 'ptc';
    readonly rawArguments?: unknown;
}
/**
 * Recursively redact sensitive keys from nested objects and arrays.
 * @param val - Value to recursively redact.
 * @param depth - Current recursion depth.
 * @returns Redacted object or primitive.
 */
export declare function redactSecrets(val: unknown, depth?: number): unknown;
/**
 * Summarize and bound a tool argument payload, recursively redacting known secret fields.
 * @param args - Parsed or raw arguments.
 * @returns Bounded sanitized string summary.
 */
export declare function summarizeArguments(args: unknown): string;
/**
 * Look up arguments for a pending tool approval from the session log.
 * Handles both native 'tool/call' (by callId) and PTC 'tool/ptc-dispatch-start' (by subCallId).
 * @param session - The requesting agent's session.
 * @param callId - ToolCallId to look up.
 * @param expectedName - Expected tool name.
 * @returns Found status and sanitized argument summary.
 */
export declare function lookupApprovalArguments(session: Session, callId: string | undefined, expectedName: string): ApprovalArgumentsInfo;
export interface InteractionProviderHandlers {
    onInteractionStart: (promptText: string) => void;
    onInteractionEnd: () => void;
    getActiveAgent: () => Agent | undefined;
}
/** Provides interactive terminal responses to approval requests and user questions. */
export declare class InteractionProvider {
    private readonly ctx;
    private readonly renderer;
    private readonly handlers;
    private readonly dict;
    private activeItem;
    private readonly queue;
    constructor(ctx: Context, renderer: TerminalRenderer, handlers: InteractionProviderHandlers, dict: LocaleDictionary);
    /** Check whether an interactive prompt currently holds the focus. */
    get hasActiveInteraction(): boolean;
    /**
     * Handle raw key or text input directed at the active interaction.
     * @param input - Submitted string or key character.
     * @returns true if consumed by the interaction.
     */
    handleInput(input: string): boolean;
    /**
     * Cancel any pending interactions (e.g. on session switch or shutdown).
     */
    cancelPending(): void;
    private handleApprovalInput;
    private handleQuestionInput;
    private advanceQuestion;
    private renderApprovalPrompt;
    private renderQuestionPrompt;
    private activate;
    private advanceQueue;
    private handleAbort;
    private registerAnswerers;
}
//# sourceMappingURL=interaction.d.ts.map