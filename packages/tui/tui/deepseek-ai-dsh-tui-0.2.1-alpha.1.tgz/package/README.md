---
description: "Interactive terminal user interface for DeepSeek Harness, providing raw keyboard handling, rich rendering, question and approval flows, and deterministic terminal state restoration."
kind: "package"
---

# @deepseek-ai/dsh-tui

English | [中文](README.zh.md)

## Summary

`@deepseek-ai/dsh-tui` provides an interactive terminal user interface for DeepSeek Harness. It runs inside the user's terminal emulator using raw mode, bracketed paste, multiline prompt buffering, grapheme-aware Unicode column measurement, bounded scrollback history, streaming assistant updates, interactive user question selection, and tool execution approval and rejection. It integrates with `@deepseek-ai/dsh-app-boot` terminal restore services to guarantee deterministic terminal cleanup before fatal diagnostics or process exit.

## Table of Contents

- [Use this package](#use-this-package)
- [Configuration](#configuration)
- [Model Experience](#model-experience)
- [Known Limitations and Deferred Work](#known-limitations-and-deferred-work)
- [Dev Note](#dev-note)

-----

<a id="use-this-package"></a>
## Use this package

The plugin mounts into a Cordis context that provides an agent service, user approval, and user question services.

```ts
import { Context } from '@deepseek-ai/cordis'
import * as TuiPlugin from '@deepseek-ai/dsh-tui'

const ctx = new Context()
await ctx.plugin(TuiPlugin, {
  locale: 'zh',
  maxScrollbackLines: 5000,
})
```

The plugin requires an interactive TTY on standard input and standard output, refusing initialization with exit code 1 when invoked without a TTY.

<a id="configuration"></a>
## Configuration

| Field | Type | Default | Description |
|---|---|---|---|
| `locale` | `'zh' \| 'en'` | `'zh'` | UI display language |
| `maxScrollbackLines` | `number` | `5000` | Maximum number of lines retained in scrollback history |

<a id="model-experience"></a>
## Model Experience

None, as the interactive TUI submits tasks as ordinary user messages and renders terminal views without modifying model requests.

#### KV Cache effect

The interactive TUI adds nothing to the request prefix; it only submits user messages and interaction responses.

## Known Limitations and Deferred Work

<a id="known-limitations-and-deferred-work"></a>

- **Interactive TTY required** — the plugin requires an interactive TTY and does not support headless or piped execution.
- **Single active session** — the current TUI manages one foreground session at a time and switches sessions via commands.

-----

<a id="dev-note"></a>
### Dev Note

<details>
<summary>Working context for maintainers — click to expand</summary>

None.

</details>
