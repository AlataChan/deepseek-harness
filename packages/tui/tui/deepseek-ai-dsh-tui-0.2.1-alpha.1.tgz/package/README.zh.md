---
description: "DeepSeek Harness 交互式终端用户界面，提供原始键盘处理、富文本渲染、提问与审批流程，以及确定性终端状态复原。"
kind: "package"
---

# @deepseek-ai/dsh-tui

[English](README.md) | 中文

## 概述

`@deepseek-ai/dsh-tui` 为 DeepSeek Harness 提供交互式终端用户界面。它使用 raw 模式、括号粘贴、多行提示缓冲、字素感知 Unicode 列宽计算、有界回滚历史、助手流式更新、交互式用户提问选择，以及工具执行审批与拒绝，直接运行在用户终端模拟器内。它与 `@deepseek-ai/dsh-app-boot` 终端复原服务集成，确保在致命诊断输出或进程退出前完成确定性的终端清理。

## 目录

- [使用本包](#use-this-package)
- [配置](#configuration)
- [Model Experience](#model-experience)
- [Known Limitations and Deferred Work](#known-limitations-and-deferred-work)
- [开发备注](#dev-note)

-----

<a id="use-this-package"></a>
## 使用本包

本插件挂载到提供 agent 服务、用户审批与用户提问服务的 Cordis 上下文中。

```ts
import { Context } from '@deepseek-ai/cordis'
import * as TuiPlugin from '@deepseek-ai/dsh-tui'

const ctx = new Context()
await ctx.plugin(TuiPlugin, {
  locale: 'zh',
  maxScrollbackLines: 5000,
})
```

本插件在标准输入与标准输出上要求交互式 TTY，在非 TTY 环境下调用时会拒绝初始化并以状态码 1 退出。

<a id="configuration"></a>
## 配置

| 字段 | 类型 | 默认值 | 说明 |
|---|---|---|---|
| `locale` | `'zh' \| 'en'` | `'zh'` | 界面展示语言 |
| `maxScrollbackLines` | `number` | `5000` | 回滚历史中保留的最大行数 |

<a id="model-experience"></a>
## Model Experience

None, as the interactive TUI submits tasks as ordinary user messages and renders terminal views without modifying model requests.

#### KV Cache effect

The interactive TUI adds nothing to the request prefix; it only submits user messages and interaction responses.

## Known Limitations and Deferred Work

<a id="known-limitations-and-deferred-work"></a>

- **要求交互式 TTY**——本插件需要交互式 TTY，不支持无头或管道化执行。
- **单一活跃会话**——当前 TUI 一次管理一个前台会话，通过命令切换会话。

-----

<a id="dev-note"></a>
### 开发备注

<details>
<summary>维护者的工作上下文——点击展开</summary>

无。

</details>
